{
  script: 'app.js',
  ext: 'js html jade',
  env: { 'NODE_ENV': 'development' }
}