module.exports = {
	'url' : 'mongodb://127.0.0.1:27017/turaco'
};

//module.exports = {
//	'url' : 'mongodb://turacoapp.com:27017/turaco'
//};

