define([
	'./user_factories',
	'./error_factories',
	'./list_factories'
], function () {});
