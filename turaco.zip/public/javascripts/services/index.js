define([
	'./user_service',
	'./list_service'
], function () {});

