define([
	'./user_controller',
	'./modal_lists_controller',
	'./modal_confirm_controller',
	'./modal_loading_controller',
	'./list_controller',
	'./error_controller'
], function () {});
