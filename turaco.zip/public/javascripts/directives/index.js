define([
	'./turaco_directives'
], function () {});
